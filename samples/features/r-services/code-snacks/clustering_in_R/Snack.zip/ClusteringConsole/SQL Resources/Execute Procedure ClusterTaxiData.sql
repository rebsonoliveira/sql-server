USE [taxidata]
GO

EXEC [dbo].[ClusterTaxiData]  
