-- Creates a schema for the external data
CREATE SCHEMA ext;
GO
