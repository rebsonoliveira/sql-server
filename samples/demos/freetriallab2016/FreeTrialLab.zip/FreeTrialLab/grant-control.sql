-- Grants control of DW db to new user
GRANT CONTROL ON DATABASE::NYT to XLRCUser;