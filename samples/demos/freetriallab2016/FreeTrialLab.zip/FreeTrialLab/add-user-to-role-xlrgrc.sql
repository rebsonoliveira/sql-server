-- Adds user XLRCUser to the xlargerc resource class role
EXEC sp_addrolemember 'xlargerc', 'XLRCUser'