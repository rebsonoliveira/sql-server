-- Shows rows and space used per distribution
DBCC PDW_SHOWSPACEUSED ("dbo.Trip")