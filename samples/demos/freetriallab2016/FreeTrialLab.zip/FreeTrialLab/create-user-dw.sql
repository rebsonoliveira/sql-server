-- Connect to SQL DW database and create a database user
CREATE USER XLRCUser FOR LOGIN XLRCLogin;
